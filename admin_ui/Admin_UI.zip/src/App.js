import UserManagement from "./components/UserManagement";
import './App.css';

function App() {
  return (
    <div className="App">
      <UserManagement />
    </div>
  );
}

export default App;
